module.exports = {
	PORT: process.env.PORT,
	HOST: process.env.HOST,
	JWTSECRET: process.env.JWT_SECRET,
};
