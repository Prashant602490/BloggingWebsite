exports.userController = require('./user');
exports.postController = require('./posts');
exports.profileController = require('./profile');
exports.likeController = require('./postLikes');
exports.commentController = require('./comments');
