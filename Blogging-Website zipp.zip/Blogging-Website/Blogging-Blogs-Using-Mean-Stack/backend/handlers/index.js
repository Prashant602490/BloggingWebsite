exports.userHandler = require('./users');
exports.postHandler = require('./posts');
exports.profileHandler = require('./profile');
exports.likeHandler = require('./postLikes');
exports.commentHandler = require('./comments');
